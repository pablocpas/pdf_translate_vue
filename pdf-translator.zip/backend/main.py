from fastapi import FastAPI, UploadFile, HTTPException, BackgroundTasks, Form, Request, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel
from enum import Enum
from typing import Optional
import uuid
import os
from pathlib import Path
from celery import Celery

# Configure Celery
celery_app = Celery(
    'pdf_translator',
    broker=os.getenv('CELERY_BROKER_URL', 'redis://redis:6379/0'),
    backend=os.getenv('CELERY_RESULT_BACKEND', 'redis://redis:6379/0')
)

# Crear directorios para almacenar archivos
UPLOAD_DIR = Path("uploads")
TRANSLATED_DIR = Path("translated")
UPLOAD_DIR.mkdir(exist_ok=True)
TRANSLATED_DIR.mkdir(exist_ok=True)

class TaskStatus(str, Enum):
    pending = "pending"
    processing = "processing"
    completed = "completed"
    failed = "failed"

class TranslationProgress(BaseModel):
    current: int = 0
    total: int = 0
    percent: int = 0

class TranslationTask(BaseModel):
    id: str
    status: TaskStatus
    originalFile: str
    translatedFile: Optional[str] = None
    error: Optional[str] = None
    progress: Optional[TranslationProgress] = None

class TranslateRequest(BaseModel):
    target_language: str = "es"

class UploadResponse(BaseModel):
    taskId: str

# Almacenamiento en memoria de las tareas (en producción usar una BD)
tasks: dict[str, TranslationTask] = {}

app = FastAPI(title="PDF Translator API")

# Configurar CORS para desarrollo
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/pdfs/translate", response_model=UploadResponse)
async def upload_pdf(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    target_language: str = Form("es")
):
    # Aquí file y target_language ya están parseados
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Solo PDF")

    if file.content_type != "application/pdf":
        raise HTTPException(status_code=400, detail="Tipo no válido")
    try:
        print("Datos recibidos:")
        print(f"- Archivo: {file.filename}")
        print(f"- Idioma destino: {target_language}")
        print(f"- Content-Type: {file.content_type}")

    
        if not file.filename.lower().endswith('.pdf'):
            raise HTTPException(status_code=400, detail="Solo se permiten archivos PDF")
        
        if not file.content_type == 'application/pdf':
            raise HTTPException(
                status_code=400, 
                detail=f"Tipo de contenido no válido: {file.content_type}. Se espera application/pdf"
            )
        
        print(f"Recibiendo archivo: {file.filename}")
    except Exception as e:
        print(f"Error al procesar la solicitud: {str(e)}")
        raise HTTPException(status_code=422, detail=f"Error al procesar la solicitud: {str(e)}")
    
    # Generar ID único para la tarea
    task_id = str(uuid.uuid4())
    
    # Guardar el archivo
    file_path = UPLOAD_DIR / f"{task_id}.pdf"
    with open(file_path, "wb") as buffer:
        content = await file.read()
        buffer.write(content)
    
    # Crear y guardar la tarea
    task = TranslationTask(
        id=task_id,
        status=TaskStatus.processing,
        originalFile=str(file_path)
    )
    tasks[task_id] = task
    
    # Enviar tarea al worker de Celery
    celery_task = celery_app.send_task(
        'translate_pdf',
        args=[task_id, str(file_path), target_language]
    )
    
    # Función para actualizar el estado de la tarea
    def update_task_status():
        try:
            # Check task state first
            task_state = celery_task.state
            if task_state == 'PROGRESS':
                # Get progress info
                task_info = celery_task.info
                tasks[task_id].progress = TranslationProgress(
                    current=task_info['current'],
                    total=task_info['total'],
                    percent=task_info['percent']
                )
            else:
                # Try to get final result
                result = celery_task.get(timeout=1)
                if result["status"] == "completed":
                    tasks[task_id].status = TaskStatus.completed
                    tasks[task_id].translatedFile = result["translated_file"]
                elif result["status"] == "failed":
                    tasks[task_id].status = TaskStatus.failed
                    tasks[task_id].error = result.get("error")
        except Exception as e:
            if celery_task.state == 'PROGRESS':
                # If task is still in progress, don't mark as failed
                return
            tasks[task_id].status = TaskStatus.failed
            tasks[task_id].error = str(e)
    
    background_tasks.add_task(update_task_status)
    return UploadResponse(taskId=task_id)

@app.get("/pdfs/status/{task_id}", response_model=TranslationTask)
async def get_translation_status(task_id: str):
    task = tasks.get(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Tarea no encontrada")
    return task

@app.get("/pdfs/download/{task_id}")
async def download_translated_pdf(task_id: str):
    task = tasks.get(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Tarea no encontrada")
    
    if task.status != TaskStatus.completed:
        raise HTTPException(status_code=400, detail="La traducción no está completa")
    
    if not task.translatedFile:
        raise HTTPException(status_code=404, detail="Archivo traducido no encontrado")
    
    return FileResponse(
        task.translatedFile,
        media_type="application/pdf",
        filename=f"translated_{task_id}.pdf"
    )

# Endpoint de prueba
@app.get("/")
async def read_root():
    return {"message": "PDF Translator API"}
