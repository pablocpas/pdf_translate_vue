<template>
  <div class="upload-container">
    <div class="upload-card">
      <h2 class="title">Traductor de PDF</h2>
      
      <div v-if="errors.general" class="error-banner">
        {{ errors.general }}
      </div>

      <form @submit.prevent="handleSubmit">
        <div class="form-group">
          <label class="form-label">
            Archivo PDF <span class="required">*</span>
          </label>
          <input
            type="file"
            accept="application/pdf"
            @change="handleFileChange"
            class="file-input"
            :class="{ 'has-error': errors.file }"
          />
          <div class="file-info" v-if="form.file">
            <span class="file-name">{{ form.file.name }}</span>
            <span class="file-size">({{ fileSize }})</span>
          </div>
          <span v-if="errors.file" class="error-text">{{ errors.file }}</span>
        </div>

        <div v-if="isSubmitting" class="progress-container">
          <div 
            class="progress-bar"
            :style="{ width: `${uploadProgress}%` }"
          ></div>
          <span class="progress-text">{{ uploadProgress }}%</span>
        </div>

        <div class="form-group">
          <label class="form-label">
            Idioma destino <span class="required">*</span>
          </label>
          <select
            v-model="form.targetLanguage"
            class="select-input"
            :class="{ 'has-error': errors.targetLanguage }"
          >
            <option value="">Selecciona un idioma</option>
            <option
              v-for="lang in languages"
              :key="lang.code"
              :value="lang.code"
            >
              {{ lang.nativeName }}
            </option>
          </select>
          <span v-if="errors.targetLanguage" class="error-text">{{ errors.targetLanguage }}</span>
        </div>

        <button
          type="submit"
          class="submit-button"
          :disabled="isSubmitting"
        >
          <span v-if="isSubmitting">Procesando...</span>
          <span v-else>Traducir PDF</span>
        </button>
      </form>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed } from 'vue';
import { useRouter } from 'vue-router';
import { useMutation } from '@tanstack/vue-query';
import { z } from 'zod';
import { useAuthStore } from '@/stores/authStore';
import { useTranslationStore } from '@/stores/translationStore';
import { uploadPdf } from '@/api/pdfs';
import type { Language } from '@/types';
import { ApiRequestError, NetworkError } from '@/types/api';

const router = useRouter();
const authStore = useAuthStore();
const translationStore = useTranslationStore();

// Constantes
const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
const ALLOWED_MIME_TYPES = ['application/pdf'];

const languages: Language[] = [
  { code: 'es', name: 'Spanish', nativeName: 'Español' },
  { code: 'en', name: 'English', nativeName: 'English' },
  { code: 'fr', name: 'French', nativeName: 'Français' },
  { code: 'de', name: 'German', nativeName: 'Deutsch' },
  { code: 'it', name: 'Italian', nativeName: 'Italiano' },
  { code: 'pt', name: 'Portuguese', nativeName: 'Português' },
];

// Esquema de validación
const schema = z.object({
  file: z.custom<File>(
    (file) => file instanceof File && 
              ALLOWED_MIME_TYPES.includes(file.type) &&
              file.size <= MAX_FILE_SIZE,
    {
      message: `Por favor selecciona un archivo PDF de menos de ${MAX_FILE_SIZE / 1024 / 1024}MB`
    }
  ),
  targetLanguage: z.string().min(1, 'Por favor selecciona un idioma'),
});

// Estado del formulario
const form = reactive({
  file: null as File | null,
  targetLanguage: '',
});

const errors = reactive({
  file: '',
  targetLanguage: '',
  general: '',
});

const uploadProgress = ref(0);
const isSubmitting = ref(false);

// Computed properties
const fileSize = computed(() => {
  if (!form.file) return '';
  const size = form.file.size / 1024; // KB
  return size > 1024 
    ? `${(size / 1024).toFixed(2)} MB`
    : `${Math.round(size)} KB`;
});

// Manejadores de eventos
const handleFileChange = (event: Event) => {
  const input = event.target as HTMLInputElement;
  if (input.files?.length) {
    form.file = input.files[0];
    errors.file = '';
    
    // Validar tipo de archivo
    if (!ALLOWED_MIME_TYPES.includes(form.file.type)) {
      errors.file = 'Solo se permiten archivos PDF';
      form.file = null;
      input.value = '';
      return;
    }
    
    // Validar tamaño
    if (form.file.size > MAX_FILE_SIZE) {
      errors.file = `El archivo es demasiado grande. Máximo ${MAX_FILE_SIZE / 1024 / 1024}MB`;
      form.file = null;
      input.value = '';
      return;
    }
  }
};

const validate = () => {
  // Limpiar errores previos
  Object.keys(errors).forEach(key => {
    errors[key as keyof typeof errors] = '';
  });
  
  const result = schema.safeParse(form);
  if (!result.success) {
    result.error.errors.forEach((error) => {
      const path = error.path[0] as keyof typeof errors;
      errors[path] = error.message;
    });
    return false;
  }
  return true;
};

// Mutación para subir archivo
const mutation = useMutation({
  mutationFn: async (formData: FormData) => {
    const response = await uploadPdf(formData);
    translationStore.setCurrentTask({
      id: response.taskId,
      status: 'pending',
      originalFile: form.file!.name
    });
    return response;
  },
  onSuccess: (data) => {
    router.push('/result');
  },
  onError: (error: Error) => {
    if (error instanceof ApiRequestError) {
      errors.general = `Error: ${error.message}`;
    } else if (error instanceof NetworkError) {
      errors.general = 'Error de conexión. Por favor, intenta de nuevo.';
    } else {
      errors.general = 'Error inesperado. Por favor, intenta de nuevo.';
    }
    console.error('Error al subir archivo:', error);
  },
});

const handleSubmit = async () => {
  if (!validate()) return;
  
  isSubmitting.value = true;
  uploadProgress.value = 0;
  errors.general = '';
  
  try {
    const formData = new FormData();
    // Asegurarnos de que el archivo se envía con el tipo correcto
    const file = new File([form.file!], form.file!.name, {
      type: 'application/pdf'
    });
    formData.append('file', file);
    formData.append('target_language', form.targetLanguage);
    await mutation.mutateAsync(formData);
  } finally {
    isSubmitting.value = false;
  }
};
</script>

<style scoped>
.upload-container {
  max-width: 600px;
  margin: 2rem auto;
  padding: 0 1rem;
  animation: slideUp 0.5s ease-out;
}

.upload-card {
  background: white;
  border-radius: 12px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05), 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(0, 0, 0, 0.1);
  padding: 2.5rem;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.upload-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 8px rgba(0, 0, 0, 0.05), 0 2px 4px rgba(0, 0, 0, 0.1);
}

.title {
  font-size: 1.625rem;
  margin: 0 0 2rem 0;
  color: #1a1b1e;
  font-weight: 700;
  text-align: center;
  background: linear-gradient(45deg, #228be6, #15aabf);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  letter-spacing: -0.02em;
}

.form-group {
  margin-bottom: 1.75rem;
}

.form-label {
  display: block;
  margin-bottom: 0.625rem;
  font-weight: 600;
  color: #1a1b1e;
  font-size: 0.9375rem;
  letter-spacing: -0.01em;
}

.required {
  color: #fa5252;
  margin-left: 4px;
}

.file-input,
.select-input {
  width: 100%;
  padding: 0.75rem;
  border: 2px solid #e9ecef;
  border-radius: 8px;
  background: white;
  transition: all 0.2s ease;
  font-size: 0.9375rem;
  letter-spacing: -0.01em;
}

.file-input:hover,
.select-input:hover {
  border-color: #74c0fc;
}

.file-input:focus,
.select-input:focus {
  outline: none;
  border-color: #228be6;
  box-shadow: 0 0 0 3px rgba(34, 139, 230, 0.15);
}

.has-error {
  border-color: #fa5252;
}

.error-text {
  display: block;
  margin-top: 0.5rem;
  color: #fa5252;
  font-size: 0.8125rem;
  font-weight: 500;
  animation: shake 0.5s ease-in-out;
  letter-spacing: -0.01em;
}

.submit-button {
  width: 100%;
  padding: 0.875rem;
  background: linear-gradient(45deg, #228be6, #15aabf);
  color: white;
  border: none;
  border-radius: 8px;
  font-weight: 600;
  font-size: 0.9375rem;
  cursor: pointer;
  transition: all 0.2s ease;
  position: relative;
  overflow: hidden;
  letter-spacing: -0.01em;
}

.submit-button:hover {
  transform: translateY(-1px);
  box-shadow: 0 4px 8px rgba(34, 139, 230, 0.25);
}

.submit-button:active {
  transform: translateY(1px);
}

.submit-button:disabled {
  background: linear-gradient(45deg, #74c0fc, #66d9e8);
  cursor: not-allowed;
  transform: none;
  box-shadow: none;
}

.error-banner {
  background-color: #fff5f5;
  border: 2px solid #ffc9c9;
  border-radius: 8px;
  color: #e03131;
  padding: 1rem 1.25rem;
  margin-bottom: 2rem;
  font-size: 0.95rem;
  animation: shake 0.5s ease-in-out;
}

.file-info {
  margin-top: 0.625rem;
  font-size: 0.875rem;
  color: #495057;
  padding: 0.5rem 0.75rem;
  background: #f8f9fa;
  border-radius: 6px;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  letter-spacing: -0.01em;
}

.file-name {
  font-weight: 600;
  color: #228be6;
  letter-spacing: -0.01em;
}

.file-size {
  color: #868e96;
  font-weight: 500;
}

.progress-container {
  margin: 1.5rem 0;
  background-color: #e9ecef;
  border-radius: 8px;
  height: 10px;
  position: relative;
  overflow: hidden;
}

.progress-bar {
  height: 100%;
  background: linear-gradient(45deg, #228be6, #15aabf);
  transition: width 0.3s ease;
  border-radius: 8px;
}

.progress-text {
  position: absolute;
  right: 0;
  top: -1.75rem;
  font-size: 0.8125rem;
  color: #495057;
  font-weight: 500;
  letter-spacing: -0.01em;
}

@keyframes slideUp {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes shake {
  0%, 100% { transform: translateX(0); }
  25% { transform: translateX(-4px); }
  75% { transform: translateX(4px); }
}
</style>
