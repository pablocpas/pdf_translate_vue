import { defineStore } from 'pinia';
import { ref, computed } from 'vue';
import { TranslationTask } from '@/types';
import { z } from 'zod';

const translationTaskSchema = z.object({
  id: z.string().min(1),
  status: z.enum(['pending', 'processing', 'completed', 'failed']),
  originalFile: z.string().min(1),
  translatedFile: z.string().optional(),
  error: z.string().optional()
});

export const useTranslationStore = defineStore('translation', () => {
  const currentTask = ref<TranslationTask | null>(null);

  function setCurrentTask(task: TranslationTask) {
    const parsedTask = translationTaskSchema.safeParse(task);
    if (!parsedTask.success) {
      throw new Error('Tarea de traducción inválida');
    }
    currentTask.value = task;
  }

  function clearCurrentTask() {
    currentTask.value = null;
  }

  const isTaskInProgress = computed(() => 
    currentTask.value?.status === 'pending' || 
    currentTask.value?.status === 'processing'
  );

  const hasError = computed(() => 
    currentTask.value?.status === 'failed'
  );

  const isCompleted = computed(() => 
    currentTask.value?.status === 'completed'
  );

  return {
    currentTask,
    setCurrentTask,
    clearCurrentTask,
    isTaskInProgress,
    hasError,
    isCompleted
  };
});
