import { defineStore } from 'pinia';
import { ref } from 'vue';
import { TranslationTask } from '@/types';
import { z } from 'zod';

const tokenSchema = z.string().min(1);

export const usePdfStore = defineStore('pdf', () => {
  const currentTask = ref<TranslationTask | null>(null);
  const token = ref<string>(localStorage.getItem('token') || '');

  function setToken(newToken: string) {
    const parsedToken = tokenSchema.safeParse(newToken);
    if (!parsedToken.success) {
      throw new Error('Token inválido');
    }
    token.value = newToken;
    localStorage.setItem('token', newToken);
  }

  function clearToken() {
    token.value = '';
    localStorage.removeItem('token');
  }

  function setCurrentTask(task: TranslationTask) {
    currentTask.value = task;
  }

  return {
    token,
    currentTask,
    setToken,
    clearToken,
    setCurrentTask,
  };
});
